resource "azurerm_storage_account" "stac_primary" {
  name                     = "name"
  resource_group_name      = res.name.???
  location                 = "..."
  account_tier             = "Standard"
  account_replication_type = "LRS"
}
